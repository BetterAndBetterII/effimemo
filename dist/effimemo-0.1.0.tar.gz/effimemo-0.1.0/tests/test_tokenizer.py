import pytest
from effimemo.core.tokenizer import TiktokenCounter, CachedTokenCounter

class TestTokenCounter:
    def test_count_empty_text(self):
        counter = TiktokenCounter()
        assert counter.count("") == 0
        
    def test_count_simple_text(self):
        counter = TiktokenCounter()
        text = "Hello, world!"
        count = counter.count(text)
        assert count > 0
        assert isinstance(count, int)
        
    def test_count_empty_messages(self):
        counter = TiktokenCounter()
        assert counter.count_messages([]) == 0
        
    def test_count_simple_messages(self):
        counter = TiktokenCounter()
        messages = [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "Hello!"}
        ]
        count = counter.count_messages(messages)
        assert count > 0
        assert isinstance(count, int)
        
    def test_count_tool_calls(self):
        counter = TiktokenCounter()
        messages = [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "What's the weather in Beijing?"},
            {"role": "assistant", "content": None, "tool_calls": [
                {
                    "id": "call_abc123",
                    "type": "function",
                    "function": {
                        "name": "get_weather",
                        "arguments": "{\"location\":\"Beijing\",\"unit\":\"celsius\"}"
                    }
                }
            ]},
            {"role": "tool", "tool_call_id": "call_abc123", "content": "Sunny, 25°C"}
        ]
        count = counter.count_messages(messages)
        assert count > 0
        assert isinstance(count, int)
        
    def test_cached_counter(self):
        base_counter = TiktokenCounter()
        cached_counter = CachedTokenCounter(base_counter)
        
        text = "This is a test message that should be cached."
        
        # First call should calculate
        count1 = cached_counter.count(text)
        
        # Second call should use cache
        count2 = cached_counter.count(text)
        
        assert count1 == count2
        assert text in cached_counter.cache
