"""
适配器模块初始化文件
"""

from .openai import OpenAIAdapter

__all__ = ["OpenAIAdapter"]
